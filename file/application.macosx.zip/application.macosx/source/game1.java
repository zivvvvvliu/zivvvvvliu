import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class game1 extends PApplet {

Square s;
ArrayList<pSquare> p = new ArrayList<pSquare>();
int max=10;
boolean reset=false;
int[] colors = {color(254, 212, 7), color(252, 221, 35), 
  color(247, 231, 73), color(245, 231, 111), 
  color(247, 198, 168), color(251, 160, 196), 
  color(254, 125, 220)};
int colorIndex=0;
boolean colorDir=true;

public void setup() {
  background(0xff22402E);
  
  noStroke();

  s = new Square();
}

public void draw() {
  backG();
  s.display();
  s.update();
  for (pSquare ps : p) {
    ps.display();
  }
}

public void backG()
{
  float r, g, b;
  int[] c1 = {72, 132, 130};
  int[] c2 = {174, 211, 163};
  for (int i=0; i<height; i++)
  {
    r=c1[0]+1.0f*i*(c2[0]-c1[0])/(height-1);
    g=c1[1]+1.0f*i*(c2[1]-c1[1])/(height-1);
    b=c1[2]+1.0f*i*(c2[2]-c1[2])/(height-1);
    fill(r, g, b);
    rect(0, i, width, 1);
  }
}

public void mousePressed() {
  s.click();

  if (colorDir) {
    colorIndex++;
  } else
  {
    colorIndex--;
  }
  
  if (colorIndex==-1)
  {
    colorIndex=1;
    colorDir=true;
  }
  else if(colorIndex==7)
  {
  colorIndex=5;
  colorDir=false;
  }
}
class Square {
  float x=0;
  float hei=40;
  float y=height-hei;
  float wid=200;
  float v=5;

  public void display() {
    fill(colors[colorIndex]);
    rect(x, y, wid, hei);
  }

  public void update() {
    if (x>width-wid||x<0)
    {
      v=-v;
    }
    x=x+v;
  }

  public void click() {
    pSquare newp = new pSquare();
    reset=false;
    if (p.size()>0)
    {
      pSquare prev = p.get(p.size()-1);
      if (prev.x<=x&&x<prev.x+prev.wid)
      {
        newp.x=x;
        newp.wid=prev.wid-(x-prev.x);
        wid=newp.wid;
        newp.y=y;
      } else if (prev.x>x&&prev.x<x+prev.wid)
      {
        newp.x=prev.x;
        newp.wid=prev.wid-(prev.x-x);
        newp.y=y;
        wid=newp.wid;
      } else
      {
        //    println(prev.x,prev.wid,x);
        restart();
      }
    } else {
      newp.wid=wid;
      newp.x=x;
      newp.y=y;
    }
    if (!reset) {
      newp.c=colors[colorIndex];
      p.add(newp);
    }
    if (p.size()==max)
    {
      p.remove(p.get(0));
    }
    if (y>height-hei*max)
    {
      y=y-hei;
    } else {
      for (pSquare ps : p)
      {
        ps.y+=hei;
      }
    }
  }

  public void restart()
  {
    p = new ArrayList<pSquare>();
    x=0;
    hei=40;
    y=height;
    wid=200;
    v=5;
    reset=true;
  //  colorIndex=0;
  }
}
class pSquare {
  float x;
  float hei=40;
  float y;
  float wid;
  boolean show=false;
  int c;
  

public void display(){
    
    fill(c);
    rect(x, y, wid, hei);
}

}
  public void settings() {  size(600, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "game1" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
